class TodoPage {
  constructor() {
    this.todoList = "#todo-list li";
    this.inputField = "#new-todo";
    this.deleteButton = "button[class=destroy]";
    this.checkButton = "input[type=checkbox]";
  }
}

module.exports = TodoPage;
