/// <reference types="cypress" />
const TodoPage = require("../pageFactory/TodoPage.js");
const dataSet = require("../resources/todoData.module.js");

//As you can see I'm using the Page Objects pattern and a dataset to avoid hardcoding as much as possible

describe("example to-do app", () => {
  //Creating instance of Page Object
  let todoPage = new TodoPage();

  beforeEach(() => {
    //Loads the app
    cy.visit(dataSet.url);
  });

  it("can intercept and mock request", () => {
    // Intercepts GET request to get todo items and uses my data instead
    cy.intercept("GET", dataSet.mockUrl, {
      statusCode: 200,
      body: dataSet.mockBody,
    });
    // Checks that the mock items are shown successfully
    cy.contains(dataSet.mockItem).should("be.visible");
    cy.contains(dataSet.mockItem2).should("be.visible");
  });

  it("can add a new item and delete it", () => {
    // Relevant to check the adding and deleting item actions
    // Creates the new item
    cy.get(todoPage.inputField).type(`${dataSet.firstItem}{enter}`);
    // Checks that the new item was added
    cy.get(todoPage.todoList)
      .contains(dataSet.firstItem)
      .should("include.text", dataSet.firstItem);
    // Deletes the new item. I needed to force the click because otherwise it doesn't find the button
    cy.get(todoPage.todoList)
      .last()
      .find(todoPage.deleteButton)
      .invoke("show")
      .click({ force: true });
    // Checks that the new item was deleted successfully
    cy.contains(dataSet.firstItem).should("not.exist");
  });

  it("can edit an item", () => {
    // Relevant to test the edition of an item
    // Creates the new item
    cy.get(todoPage.inputField).type(`${dataSet.fifthItem}{enter}`);
    // Looks for the checkbox and double clicks. It works better with 2 dblclicks
    cy.get(todoPage.todoList).last().dblclick().type(`edited {enter}`);
    // Asserts that the parent li has the class completed
    cy.contains("edited").should("include.text", "edited " + dataSet.fifthItem);
    // Deletes the new item
    cy.get(todoPage.todoList)
      .last()
      .find(todoPage.deleteButton)
      .invoke("show")
      .click({ force: true });
  });

  it("can mark an item as completed", () => {
    // Relevant to check if an item is successfully marked as completed
    // Creates the new item
    cy.get(todoPage.inputField).type(`${dataSet.secondItem}{enter}`);
    // Checks that the new item was added
    cy.contains(todoPage.todoList, dataSet.secondItem).should("be.visible");
    // Looks for the checkbox and clicks to complete
    cy.contains(dataSet.secondItem).parent().find(todoPage.checkButton).check();
    // Asserts that the parent li has the class completed
    cy.contains(dataSet.secondItem)
      .parents("li")
      .should("have.class", "completed");
    // Deletes the new item
    cy.get(todoPage.todoList)
      .last()
      .find(todoPage.deleteButton)
      .invoke("show")
      .click({ force: true });
  });

  it("can filter for active tasks", () => {
    // Relevant to check the Active tab
    // Creates the new item
    cy.get(todoPage.inputField).type(`${dataSet.thirdItem}{enter}`);
    // Checks that the new item was added
    cy.contains(todoPage.todoList, dataSet.thirdItem).should("be.visible");
    // Clicks on Active button
    cy.contains("Active").click();
    // Checking that the item exists and is not hidden
    cy.get(todoPage.todoList)
      .not(".hidden")
      .contains(dataSet.thirdItem)
      .should("include.text", dataSet.thirdItem);
  });

  it("can filter for completed tasks", () => {
    // Relevant to check the Completed tab
    // Creates the new item
    cy.get(todoPage.inputField).type(`${dataSet.fourthItem}{enter}`);
    // Checks that the new item was added
    cy.contains(todoPage.todoList, dataSet.fourthItem).should("be.visible");
    // Looks for the checkbox and clicks to complete
    cy.contains(dataSet.fourthItem).parent().find(todoPage.checkButton).check();
    // Clicks on Active button
    cy.contains("Completed").click();
    // Checking that the item exists
    cy.get(todoPage.todoList)
      .not(".hidden")
      .contains(dataSet.fourthItem)
      .should("include.text", dataSet.fourthItem);
  });
});
